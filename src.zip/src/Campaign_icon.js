import React from 'react';
class CIcon extends React.Component { 
    render() {      
      return (
          <img src={this.props.campaign_icon} class="img-responsive w-100 h-100" alt="..."></img>
      )
    }
  }
  export default CIcon;