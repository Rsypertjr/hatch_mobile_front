import React from 'react';

class Mediaitem extends React.Component { 

    downloadMedia(){
        const proxyurl = "https://cors-anywhere.herokuapp.com/";
        const url = this.props.download_url;

        fetch(proxyurl + url, {
            method: 'GET',
            headers: {
                'Content-Type': this.props.media_type,
                'Access-Control-Allow-Origin':'*'
            },
        })
        .then((response) => response.blob())
        .then((blob) => {
            // Create blob link to download
            const url = window.URL.createObjectURL(
            new Blob([blob]),
            );
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute(
            'download',
            `FileName.pdf`,
            );

            // Append to html link element page
            document.body.appendChild(link);

            // Start download
            link.click();

            // Clean up and remove the link
            link.parentNode.removeChild(link);
        });
    }

    copyToClipboard() {
        const el = document.createElement("textarea");
        el.value = this.props.tracking_link;
        el.setAttribute("readonly", "");
        el.style.position = "absolute";
        el.style.left = "-9999px";
        document.body.appendChild(el);
        el.select();
        el.setSelectionRange(0, 99999);
        document.execCommand("copy");
        document.body.removeChild(el);
        alert("Copied the text: " + this.props.tracking_link);
    }



    render() {      
      return (
          <div class="item">                
                <img src={this.props.cover_photo_url} class="img-responsive" alt="..." width="200" height="300"></img>
                <div class="media-buttons ui icon buttons">
                    <button class="ui button" onClick={this.copyToClipboard.bind(this, this.props.tracking_link)}><i class="fa fa-link" aria-hidden="true"></i></button>
                    <button class="ui button" onClick={this.downloadMedia.bind(this, this.props.download_url, this.props.media_type)}><i class="fa fa-download" aria-hidden="true"></i></button>
                </div>
          </div>
        
     
        )
    }
  }
  export default Mediaitem;