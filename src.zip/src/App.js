import React from 'react';
import ReactDOM from 'react-dom';
import CIcon from './Campaign_icon.js';
import CInfo from './Campaign_info.js';
import CScroller from './Campaign_scroller.js';
import './App.css';


const axios = require('axios').default;


//import { BrowserRouter as Router, Route, Link, IndexRoute } from 'react-router-dom';
//import Home from './Home';
//import About from './About';
//import Contact from './Contact';
//import Root from './Root';
//import { createBrowserHistory } from 'history';




class App extends React.Component {

  constructor() {
    super();
    this.state = {
      campaigns: []
    };

  }

  

  componentDidMount() {
    axios.get("https://www.plugco.in/public/take_home_sample_feed")
      .then(
        (res) => {
          const _campaigns = res.data.campaigns;
          console.log(_campaigns);
          this.setState({campaigns : _campaigns});
        })
        .catch((error) => {
            console.log(error);
        })
        .then(function () {
          // always executed
        });  
  }

  render() {
      return (
        <div>   


          {console.log(this.state)}       
          {      
          
          
            this.state.campaigns.map(campaign => 
              <ul key={campaign.id}>

                <div class="container">
                  <div class="row ifield">
                    <div class="col-4">    
                      <CIcon campaign_icon = {campaign.campaign_icon_url}/>
                    </div>                     
                    <CInfo campaign_name = {campaign.campaign_name} pay_per_install = {campaign.pay_per_install} />
                    <div class="col"></div>    

                  </div>

                  <CScroller medias = {campaign.medias} />

                </div>



               
              </ul>
            )
          }
        </div>
      );
  }
}
export default App;

