import React from 'react';

class CInfo extends React.Component { 
    render() {      
      return (   
            <div class="col-5 info-field">
                <p class="info itop">{this.props.campaign_name}</p>
                <p class="info ibot">{this.props.pay_per_install}</p>
            </div>
        )
    }
  }
  export default CInfo;