import React from 'react';
import Mediaitem from './Media_item.js';

class CScroller extends React.Component { 
    render() {      
      return (
                <div class="row media-group">  
                    <div class="xslide-wrapper scroller">
                        {
                            this.props.medias.map(media => (                       
                                                        
                                    <Mediaitem cover_photo_url = {media.cover_photo_url} download_url =  {media.download_url}
                                        tracking_link = {media.tracking_link} media_type = {media.media_type}  />
                            
                            ))
                        }  
                    </div>
            </div>
      )
    }
  }
  export default CScroller;